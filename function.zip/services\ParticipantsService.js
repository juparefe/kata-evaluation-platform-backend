"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const actions_1 = require("../database/actions");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
class ParticipantsService {
    constructor() {
        this.router = (0, express_1.Router)();
    }
    static async find(email) {
        try {
            const result = await (0, actions_1.Select)("participants", { email });
            console.log("Result part: ", result);
            if ("error" in result) {
                console.error("Error en find:", result.message);
                return null;
            }
            return result;
        }
        catch (error) {
            console.error("Error al consultar BD: ", error);
            return null;
        }
    }
    static async getParticipants(req, res, next) {
        try {
            const result = await (0, actions_1.Select)("participants");
            if ("error" in result) {
                return res.status(500).json({ message: result.message });
            }
            res.json(result);
        }
        catch (error) {
            next(error);
        }
    }
    static async saveParticipant(req, res, next) {
        try {
            const { full_name, email, profile, password } = req.body;
            if (!full_name || !email || !password) {
                return res.status(400).json({ message: "Nombre, correo y contraseña son requeridos" });
            }
            const password_hash = await bcryptjs_1.default.hash(password, 10);
            console.log({ email, password_hash });
            const payload = {
                full_name,
                email,
                profile: profile || null,
                password_hash
            };
            const result = await (0, actions_1.Insert)("participants", payload);
            if (result && "error" in result) {
                return res.status(500).json({ message: result.message });
            }
            res.status(201).json(result);
        }
        catch (error) {
            next(error);
        }
    }
}
exports.default = ParticipantsService;
