module.exports.DEFAULT_BINARY_ENCODINGS = ['gzip', 'deflate', 'br']
module.exports.DEFAULT_BINARY_CONTENT_TYPES = ['image/*']
