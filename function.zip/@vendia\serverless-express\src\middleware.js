const codeGenieServerlessExpressMiddleware = require('@codegenie/serverless-express/src/middleware')

module.exports.eventContext = codeGenieServerlessExpressMiddleware.eventContext
