import { URL } from 'url';

export default function createRequire (filename: string | URL): NodeRequire;
