"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const ParticipantsController_1 = __importDefault(require("../controllers/ParticipantsController"));
const JudgesController_1 = __importDefault(require("../controllers/JudgesController"));
const EvaluationsController_1 = __importDefault(require("../controllers/EvaluationsController"));
const router = (0, express_1.Router)();
router.post("/api/participants", ParticipantsController_1.default.register);
router.post("/api/judges", JudgesController_1.default.register);
router.post("/api/katas/:kataId/evaluate", EvaluationsController_1.default.evaluate);
exports.default = router;
