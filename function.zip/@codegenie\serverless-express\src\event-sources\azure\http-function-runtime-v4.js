const { getRequest, getResponse } = require('./http-function-runtime-v3')

module.exports = {
  getRequest,
  getResponse
}
