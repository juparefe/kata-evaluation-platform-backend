"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const JudgesService_1 = __importDefault(require("../services/JudgesService"));
const judgesController = (0, express_1.Router)();
judgesController.get("/V1/data/judges", async (req, res, next) => {
    await JudgesService_1.default.getJudges(req, res, next);
});
judgesController.post("/V1/data/judges", async (req, res, next) => {
    await JudgesService_1.default.saveJudge(req, res, next);
});
exports.default = judgesController;
