"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const ParticipantsService_1 = __importDefault(require("./ParticipantsService"));
const JudgesService_1 = __importDefault(require("./JudgesService"));
class AuthService {
    constructor() {
        this.router = (0, express_1.Router)();
    }
    static async login(req, res, next) {
        console.log("Request: ", req.body);
        try {
            const { email, password } = req.body;
            if (!email || !password) {
                return res.status(400).json({ message: 'Correo y contraseña son requeridos' });
            }
            let user = await ParticipantsService_1.default.find(email);
            let role = 'participant';
            if (!user || user.length === 0) {
                user = await JudgesService_1.default.find(email);
                role = 'judge';
            }
            console.log("User: ", user);
            if (!user?.length) {
                return res.status(401).json({ message: 'No se encuentra el correo' });
            }
            else {
                user = user[0];
            }
            const passwordMatch = await bcryptjs_1.default.compare(password, user.password_hash);
            if (!passwordMatch) {
                return res.status(401).json({ message: 'Credenciales inválidas' });
            }
            const token = jsonwebtoken_1.default.sign({
                id: user.id,
                full_name: user.full_name,
                role
            }, process.env.JWT_SECRET || 'supersecret', { expiresIn: '1d' });
            res.status(200).json({
                message: 'Inicio de sesión exitoso',
                user: {
                    id: user.id,
                    full_name: user.full_name,
                    email: user.email
                },
                role,
                token
            });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.default = AuthService;
