"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const ParticipantsService_1 = __importDefault(require("../services/ParticipantsService"));
const participantsController = (0, express_1.Router)();
participantsController.get("/V1/data/participants", async (req, res, next) => {
    await ParticipantsService_1.default.getParticipants(req, res, next);
});
participantsController.post("/V1/data/participants", async (req, res, next) => {
    await ParticipantsService_1.default.saveParticipant(req, res, next);
});
exports.default = participantsController;
