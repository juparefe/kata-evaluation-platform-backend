## Serverless Express is now part of Code Genie 🎉
Serverless Express has moved to [@codegenie/serverless-express](https://www.npmjs.com/package/@codegenie/serverless-express). Please update your dependencies to receive the latest changes.

```
npm uninstall @vendia/serverless-express
npm i @codegenie/serverless-express
```