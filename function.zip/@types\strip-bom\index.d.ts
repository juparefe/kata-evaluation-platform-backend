// Type definitions for strip-bom 3.0
// Project: https://github.com/sindresorhus/strip-bom#readme
// Definitions by: Mohamed Hegazy <https://github.com/mhegazy>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

export = strip_bom;
declare function strip_bom(x: string): string;
