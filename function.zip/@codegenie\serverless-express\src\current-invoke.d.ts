export interface CurrentInvoke {
    event?: any;
    context?: any;
}

export declare function getCurrentInvoke(): CurrentInvoke;
