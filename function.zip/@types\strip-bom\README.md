# Installation
> `npm install --save @types/strip-bom`

# Summary
This package contains type definitions for strip-bom (https://github.com/sindresorhus/strip-bom#readme).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/strip-bom

Additional Details
 * Last updated: Thu, 29 Dec 2016 23:09:23 GMT
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: none

# Credits
These definitions were written by Mohamed Hegazy <https://github.com/mhegazy>.
