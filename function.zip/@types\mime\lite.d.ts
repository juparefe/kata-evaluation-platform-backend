import { default as Mime } from "./Mime";

declare const mimelite: Mime;

export as namespace mimelite;

export = mimelite;
