'use strict';

console.log('loading foo from', __dirname);
exports =  module.exports = { foo: 'foobiloo' };
