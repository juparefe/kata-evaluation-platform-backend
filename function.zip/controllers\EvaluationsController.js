"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const EvaluationsService_1 = __importDefault(require("../services/EvaluationsService"));
const evaluationsController = (0, express_1.Router)();
evaluationsController.get("/V1/data/scores", async (req, res, next) => {
    await EvaluationsService_1.default.getEvaluations(req, res, next);
});
evaluationsController.get("/V1/data/scores/summary", async (req, res, next) => {
    await EvaluationsService_1.default.getEvaluationsSummary(req, res, next);
});
evaluationsController.post("/V1/data/scores", async (req, res, next) => {
    await EvaluationsService_1.default.saveEvaluation(req, res, next);
});
exports.default = evaluationsController;
