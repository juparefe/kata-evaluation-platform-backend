"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Delete = exports.Update = exports.Insert = exports.Select = void 0;
const SupaBaseClient_1 = __importDefault(require("./SupaBaseClient"));
const Select = async (table, filters = {}) => {
    const query = SupaBaseClient_1.default.from(table).select("*");
    if (filters.email)
        query.eq("email", filters.email);
    const { data, error } = await query;
    if (error) {
        console.error("Error en Select:", error);
        return { error: true, message: error.message };
    }
    return data;
};
exports.Select = Select;
const Insert = async (table, data) => {
    const { data: insertedData, error } = await SupaBaseClient_1.default.from(table).insert([data]);
    if (error) {
        console.error("Error en Insert:", error);
        return { error: true, message: error.message };
    }
    return insertedData;
};
exports.Insert = Insert;
const Update = async (table, data, filters) => {
    let query = SupaBaseClient_1.default.from(table).update(data);
    for (const key in filters) {
        query = query.eq(key, filters[key]);
    }
    const { data: updatedData, error } = await query;
    if (error) {
        console.error("Error en Update:", error);
        return { error: true, message: error.message };
    }
    return updatedData;
};
exports.Update = Update;
const Delete = async (table, filters) => {
    let query = SupaBaseClient_1.default.from(table).delete();
    for (const key in filters) {
        query = query.eq(key, filters[key]);
    }
    const { data, error } = await query;
    if (error) {
        console.error("Error en Delete:", error);
        return { error: true, message: error.message };
    }
    return data;
};
exports.Delete = Delete;
