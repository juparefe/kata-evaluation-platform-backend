'use strict';

require('../../../count').count++;
exports =  module.exports = { foo: 'foobiloo' };
