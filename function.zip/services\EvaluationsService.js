"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const actions_1 = require("../database/actions");
class EvaluationsService {
    constructor() {
        this.router = (0, express_1.Router)();
    }
    static async getEvaluations(req, res, next) {
        try {
            const result = await (0, actions_1.Select)("participant_results");
            if ("error" in result) {
                return res.status(500).json({ message: result.message });
            }
            res.json(result);
        }
        catch (error) {
            next(error);
        }
    }
    static async getEvaluationsSummary(req, res, next) {
        try {
            const result = await (0, actions_1.Select)("participant_results");
            if ("error" in result) {
                return res.status(500).json({ message: result.message });
            }
            const summary = {
                total_participants: result.length,
                approved: result.filter(r => r.status === 'Aprobado').length,
                failed: result.filter(r => r.status === 'Reprobado').length,
                top_3: result.slice(0, 3),
                generated_at: new Date().toISOString()
            };
            res.json(summary);
        }
        catch (error) {
            next(error);
        }
    }
    static async saveEvaluation(req, res, next) {
        try {
            const { participant_id, judge_id, profile_score, communication_score, technical_score, extra_points } = req.body;
            if (!participant_id || !judge_id || profile_score === undefined || communication_score === undefined || technical_score === undefined) {
                return res.status(400).json({ message: "Todos los campos (participant_id, judge_id, profile_score, communication_score, technical_score) son requeridos" });
            }
            const evaluation = {
                participant_id,
                judge_id,
                profile_score,
                communication_score,
                technical_score,
                extra_points: extra_points || 0
            };
            const result = await (0, actions_1.Insert)("scores", evaluation);
            if (result && "error" in result) {
                return res.status(500).json({ message: result.message });
            }
            res.status(201).json({ message: "Evaluación guardada correctamente", data: result });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.default = EvaluationsService;
