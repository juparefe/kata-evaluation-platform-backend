const { getRequest, getResponse } = require('./http-function-runtime-v3')

module.exports = {
  getRequest: getRequest,
  getResponse: getResponse
}
